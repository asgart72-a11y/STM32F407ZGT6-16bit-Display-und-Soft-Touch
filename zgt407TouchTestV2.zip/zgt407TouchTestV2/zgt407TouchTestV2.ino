/*
Dieses Program ist für STM32F407ZGT6 mit ILI9341 und Touchscreen zum Testen.
Verbesserungen sind erwünscht, Das Board ist zu Steuerungszwecken, für eine 
RC Fernbedienung mit NRF24 als Sender SDCarte und QSPI ausgestattet.
Der Touch ist in SoftSPI ausgefürt, Display ist 16bit auführung, es sind 
noch genügend Freie Pin's; das ein 24Kanal RCSender aufgebaut werden kann.

Und nun Viel Spaß beim Testen.




This program is designed for the STM32F407ZGT6 microcontroller, 
paired with an ILI9341 display and touchscreen, for testing purposes.
Improvements are welcome. The board is intended for 
control applications—specifically as an RC remote control 
transmitter—and is equipped with an NRF24 module, an SD card slot, 
and QSPI support.
The touchscreen interface is implemented via Software SPI, 
while the display utilizes a 16-bit interface; there are still 
sufficient free pins available to build a 24-channel RC transmitter system.

Now, have fun testing!


*/



#define TFT_Class GxTFT
#include <GxTFT.h>
#include <GxIO/STM32MICRO/GxIO_STM32F407ZET6_FSMC/GxIO_STM32F407ZET6_FSMC.h>
#include <GxCTRL/GxCTRL_ILI9341/GxCTRL_ILI9341.h>

// Touch-Pins
#define T_CLK   PB0
#define T_CS    PC13
#define T_MISO  PB2
#define T_MOSI  PF11
#define T_PEN   PB1

// Display-Setup
GxIO_STM32F407ZET6_FSMC io;
GxCTRL_ILI9341 controller(io);
TFT_Class tft(io, controller, 320, 240);

// Kalibrierungsdaten (werden durch Kalibrierung ersetzt)
int16_t rawXMin = 0, rawXMax = 2047;
int16_t rawYMin = 0, rawYMax = 2047;

// Software-SPI (bitbanging)
void spi_delay() {
  delayMicroseconds(1);
}

void writeByte(uint8_t data) {
  for (uint8_t i = 0; i < 8; i++) {
    digitalWrite(T_MOSI, (data & 0x80) ? HIGH : LOW);
    digitalWrite(T_CLK, HIGH);
    spi_delay();
    digitalWrite(T_CLK, LOW);
    spi_delay();
    data <<= 1;
  }
}

uint16_t readData() {
  uint16_t value = 0;
  for (uint8_t i = 0; i < 12; i++) {
    value <<= 1;
    digitalWrite(T_CLK, HIGH);
    if (digitalRead(T_MISO)) value |= 1;
    digitalWrite(T_CLK, LOW);
    spi_delay();
  }
  return value;
}

uint16_t readTouch(uint8_t cmd) {
  digitalWrite(T_CS, LOW);
  writeByte(cmd);
  uint16_t val = readData();
  digitalWrite(T_CS, HIGH);
  return val;
}

// Warte auf Berührung und gib Rohdaten zurück
void waitForTouch(uint16_t &x, uint16_t &y) {
  while (digitalRead(T_PEN) == HIGH); // Warten auf Druck
  delay(50); // Entprellen
  x = readTouch(0xD0); // Y zuerst
  y = readTouch(0x90); // X danach
  while (digitalRead(T_PEN) == LOW); // Warten auf Loslassen
}

// Zeichne Kreuz zur Kalibrierung
void drawCross(int16_t x, int16_t y, uint16_t color = RED) {
  tft.drawLine(x - 5, y, x + 5, y, color);
  tft.drawLine(x, y - 5, x, y + 5, color);
}

// Touch-Mapping korrigiert: invertierte Rohachsen (oben links hohe Werte)
int16_t mapTouchX(uint16_t rawX) {
  return map(rawX, rawXMax, rawXMin, 0, 320);  // TFT_X: 0–319
}

int16_t mapTouchY(uint16_t rawY) {
  return map(rawY, rawYMax, rawYMin, 0, 240);  // TFT_Y: 0–239
}

// Kalibrierung
void calibrateTouch() {
  uint16_t x, y;
  tft.fillScreen(BLACK);
  tft.setTextColor(WHITE);
  tft.setCursor(20, 10);
  tft.print("Touch die Kreuze zur Kalibrierung");

  // Links oben
  drawCross(20, 20, YELLOW);
  waitForTouch(x, y);
  rawXMax = x; // oben links = hohe Werte
  rawYMax = y;
  tft.fillCircle(20, 20, 6, GREEN);

  // Rechts unten
  drawCross(300, 220, YELLOW);
  waitForTouch(x, y);
  rawXMin = x; // unten rechts = kleine Werte
  rawYMin = y;
  tft.fillCircle(300, 220, 6, GREEN);

  // Mitte (optional)
  drawCross(160, 120, CYAN);
  waitForTouch(x, y);
  tft.setCursor(20, 200);
  tft.print("Mitte: ");
  tft.print(x); tft.print(", "); tft.println(y);

  delay(1000);
  tft.fillScreen(BLACK);
  tft.setCursor(10, 10);
  waitForTouch(x, y);
  tft.println("Kalibrierung fertig.");
}

void setup() {
  Serial.begin(115200);
   tft.init();
  tft.setRotation(1);  // Landscape
  tft.fillScreen(BLACK);

 pinMode(T_CLK, OUTPUT);
  pinMode(T_CS, OUTPUT);
  pinMode(T_MOSI, OUTPUT);
  pinMode(T_MISO, INPUT);
  pinMode(T_PEN, INPUT_PULLUP);
  digitalWrite(T_CS, HIGH);
  digitalWrite(T_CLK, LOW);

  calibrateTouch();
}

void loop() {
  if (digitalRead(T_PEN) == LOW) {
    uint16_t rawX = readTouch(0x90);  // Y
    uint16_t rawY = readTouch(0xD0);  // X
    int16_t px = mapTouchX(rawX);
    int16_t py = mapTouchY(rawY);

    tft.fillCircle(px, py, 3, GREEN);

    Serial.print("Touch: X=");
    Serial.print(px);
    Serial.print(" Y=");
    Serial.println(py);

    delay(300);
  
  }
}
